package gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

@SuppressWarnings("serial")
public class ColorRenderer extends DefaultTableCellRenderer{
	
	@Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    	
    	Component cell = super.getTableCellRendererComponent (table, value, isSelected, hasFocus, row, column);
    	  
    	
    	if (column == 0)
    		 cell.setForeground(Color.BLACK);
    	else{
    		if( value instanceof Integer ) {
	            Integer amount = (Integer) value;
	            if(amount == Main.BLANK){//Vacia
	                cell.setBackground( Color.white);
	                cell.setForeground( Color.white);
	            }
	            else if(amount == Main.ADMIN){//admin
	                cell.setBackground( Color.blue);
	                cell.setForeground(Color.blue);   
	            }
	            else if(amount == Main.SOCIO){//socio
	            	cell.setBackground( Color.green );
	                cell.setForeground(Color.green);           	
	            }
    		}
    	}
    	
        return cell;
    }
}






