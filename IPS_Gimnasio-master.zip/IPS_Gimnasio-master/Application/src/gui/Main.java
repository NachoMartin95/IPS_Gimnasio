package gui;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.util.Calendar;
import java.util.List;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JTable;

import reservation.Agenda;
import reservation.Instalacion;
import reservation.Reservation;


import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableCellRenderer;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.SwingConstants;
import javax.swing.JPanel;

public class Main {
	
	//Constantes para rellenar el calendario con los colores
	final static int BLANK = 0;
	final static int ADMIN = 1;
	final static int SOCIO = 2;

	private JFrame frame;
	private ModeloNoEditable modeloTabla;
	private JTable tableMain;
	Agenda agenda;
	private JLabel lblFechaIni;
	private JComboBox<Instalacion> cbInstalaciones ;

	private VentanaReserva vR;
	private Main m = this;
	private JPanel pnlSouth;
	private JLabel lblInstalacinSeleccionada;
	private JButton btnLessWeek;
	private JButton btnPlusWeek;
	private JScrollPane sclTablaMain;
	private JPanel pnlNorth;
	private JLabel lblAdmin;

	/**
	*
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
		
	}

	/**
	 * inicializa los componentes ademas de añadir algunos gatillos
	 */
	protected void initialize() {		
		frame = new JFrame();
		frame.setBounds(100, 100, 1600, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		frame.setLocationRelativeTo(null);

		frame.getContentPane().add(getPnNorth() , BorderLayout.NORTH);
		frame.getContentPane().add(getBtnLessWeek(), BorderLayout.WEST);
		frame.getContentPane().add(getBtnPlusWeek(), BorderLayout.EAST);
		frame.getContentPane().add(getPnSouth(), BorderLayout.SOUTH);
		frame.getContentPane().add(getSclTableMain(), BorderLayout.CENTER);
		
		
		initializeCalendar();
		updateDate();
		
		
	}
	
	private JLabel getLblFechaIni() {
		if (lblFechaIni == null) {
			lblFechaIni = new JLabel("Desde: 10-9-2016");
			lblFechaIni.setHorizontalTextPosition(SwingConstants.CENTER);
			lblFechaIni.setHorizontalAlignment(SwingConstants.CENTER);
			lblFechaIni.setFont(new Font("Tahoma", Font.BOLD, 20));
		}
		return lblFechaIni;
	}
	
	private JButton getBtnLessWeek() {
		if(btnLessWeek==null){
			btnLessWeek = new JButton("<");
			btnLessWeek.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					agenda.oneWeekLess();
					fillCalendar();
					updateDate();
				}
			});
		}
		return btnLessWeek;
	}
	
	private JButton getBtnPlusWeek(){
		if(btnPlusWeek==null){
			btnPlusWeek = new JButton(">");
			btnPlusWeek.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					agenda.oneWeekMore();
					fillCalendar();
					updateDate();
				}
			});
		}
		return btnPlusWeek;
	}
	private JPanel getPnNorth() {
		if (pnlNorth == null) {
			pnlNorth = new JPanel();
			pnlNorth.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			pnlNorth.add(getLblFechaIni());
			pnlNorth.add(getLblAdmin());
		}
		return pnlNorth;
	}
	
	
	

	
	
	private JPanel getPnSouth() {
		if (pnlSouth == null) {
			pnlSouth = new JPanel();
			pnlSouth.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			pnlSouth.add(getLblInstalacionSeleccionada(), BorderLayout.NORTH);
			pnlSouth.add(getCbInstalaciones());
		}
		return pnlSouth;
	}
	
	private JLabel getLblInstalacionSeleccionada() {
		if (lblInstalacinSeleccionada == null) {
			lblInstalacinSeleccionada = new JLabel("Instalaci\u00F3n seleccionada:  ");
			lblInstalacinSeleccionada.setFont(new Font("Tahoma", Font.BOLD, 20));
			lblInstalacinSeleccionada.setHorizontalAlignment(SwingConstants.RIGHT);
		}
		return lblInstalacinSeleccionada;
	}
	
	public JComboBox<Instalacion> getCbInstalaciones() {
		if (cbInstalaciones == null) {
			cbInstalaciones = new JComboBox<Instalacion>();
			cbInstalaciones.setFont(new Font("Tahoma", Font.PLAIN, 20));
			cbInstalaciones.setModel(new DefaultComboBoxModel(Instalacion.values()));
			cbInstalaciones.addItemListener(new ItemListener(){
				@Override
				public void itemStateChanged(ItemEvent arg0) {
					fillCalendar();
				}		
			});		
			cbInstalaciones.setSelectedIndex(0);
		}
		return cbInstalaciones;
	}
	
	
	
	
	
	
	/**
	*Actualiza la fecha mostrada encima del calendario con la ayuda de la Agenda
	*/
	private void updateDate(){	
		Calendar auxCalendar = (Calendar) agenda.getCalendar().clone();
		auxCalendar.add(Calendar.DAY_OF_MONTH, (auxCalendar.get(Calendar.DAY_OF_WEEK)-2)*-1);
		String prev = (auxCalendar.get(Calendar.DAY_OF_MONTH)+"-"+auxCalendar.get(Calendar.MONTH)+"-"+auxCalendar.get(Calendar.YEAR));
		auxCalendar.add(Calendar.DAY_OF_MONTH, 6);
		getLblFechaIni().setText("Desde: 17-9-2016  hasta:     ");//actualizar lbl
		getLblAdmin().setText("Administracion: Azul, Socio: Verde");
	}
	
	
	private JLabel getLblAdmin() {
		if (lblAdmin == null) {
			lblAdmin = new JLabel("Administracion: Azul, Socio: Verde");
			lblAdmin.setHorizontalTextPosition(SwingConstants.CENTER);
			lblAdmin.setHorizontalAlignment(SwingConstants.CENTER);
			lblAdmin.setFont(new Font("Tahoma", Font.BOLD, 20));
		}
		return lblAdmin;
	}
	

	private JScrollPane getSclTableMain() {
		if (sclTablaMain == null) {
			sclTablaMain = new JScrollPane(tableMain);
			sclTablaMain.setViewportView(getTableMain());
		}
		return sclTablaMain;
	}
	
	private JTable getTableMain() {
		if (tableMain == null) {
			String[] nombreColumnas ={"","Lunes","Martes","Miercoles","Jueves", "Viernes", "Sabado","Domingo"};//creado a mano, nombres de columnas
			modeloTabla = new ModeloNoEditable(nombreColumnas,0);//creado a mano
			tableMain=new JTable(modeloTabla);
			
			
			tableMain.setRowSelectionAllowed(false);
			tableMain.getTableHeader().setReorderingAllowed(false);
			tableMain.setRowHeight(28);
//			
			//COLOR RENDERER ESTA MAL, HACE QUE LA TABLA NO SE DIBUJE BIEN
			tableMain.setDefaultRenderer(Object.class, new ColorRenderer());
			tableMain.getTableHeader().setReorderingAllowed(false);//para que no se puedan mover las columnas entre si
				
			a�adirFilas();
			tableMain.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					int row = tableMain.getSelectedRow();
					int col = tableMain.getSelectedColumn();
					
					if(e.getClickCount()==2){				
						if(!tableMain.getModel().getValueAt(row, col).equals(BLANK))
							System.out.println("Instalacion ocupada");
						
						else{			
							Calendar c = (Calendar) agenda.getCalendar().clone();
							c.add(Calendar.DAY_OF_MONTH, col-1);
							String dia = (c.get(Calendar.YEAR)+"-"+(c.get(Calendar.MONTH)+1)+"-"+c.get(Calendar.DAY_OF_MONTH));
							
							vR = new VentanaReserva(m, dia, row);
							vR.setVisible(true);
						}
					}
				}
			});
			
			tableMain.addComponentListener(new ComponentAdapter(){
	            @Override
	            public void componentResized(ComponentEvent e)
	            {
	                tableMain.setRowHeight(16);
	                Dimension p = tableMain.getPreferredSize();
	                Dimension v = sclTablaMain.getViewportBorderBounds().getSize();
	                if (v.height > p.height)
	                {
	                    int available = v.height - tableMain.getRowCount() * tableMain.getRowMargin();
	                    int perRow = available / tableMain.getRowCount();
	                    tableMain.setRowHeight(perRow);
	                }
	            }
			});
			
		}
		return tableMain;
	}
	
	/*
	*Iniicializa el calendario y lo adapta a la pantalla
	*/
	private void initializeCalendar() {
		agenda = new Agenda();	
		fillCalendar();
	}
	
	/**
	*Rellena el calendario con los datos proporcionados por la agenda y el combobox
	*
	*/
	void fillCalendar() {
		modeloTabla.getDataVector().clear();
		a�adirFilas();
		Instalacion currentInstalacion = (Instalacion) cbInstalaciones.getSelectedItem();
		
		for(int i=0;i< 24;i++)//bucle que recorre las horas, de inicio pone todas las casillas en blanco
			modeloTabla.setValueAt("From "+i+":00 to "+i+":59", i, 0);
		
		for(int i = 0;i < modeloTabla.getRowCount();i++)
			for(int j = 1;j <modeloTabla.getColumnCount() ;j++)
				modeloTabla.setValueAt(new Integer(BLANK), i, j);	
		
		
		
		agenda.loadCurrentWeek();
		List<Reservation> reservations = agenda.getReservations();	
		
		Calendar dateI = Calendar.getInstance(); //un ejemplo de esta semana
		dateI.set(Calendar.YEAR, 2016);
		dateI.set(Calendar.MONTH, 10);
		dateI.set(Calendar.DAY_OF_MONTH, 15);
		dateI.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
		dateI.set(Calendar.HOUR_OF_DAY, 14);
		
		Calendar dateF = Calendar.getInstance();
		dateF.set(Calendar.YEAR, 2016);
		dateF.set(Calendar.MONTH, 10);
		dateF.set(Calendar.DAY_OF_MONTH, 15);
		dateI.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
		dateF.set(Calendar.HOUR, 14);
		
		//a�ado 1 para pruebas, se a�ade a todos los jueves a las 2		
		reservations.add(new Reservation(dateI, dateF, "Gimnasio",true));
		
		for(Reservation res: reservations){
			if(currentInstalacion.equals(res.getInstalacion())){
//				for(int i = res.getStartHour();i < res.getEndHour();i++)
//					modeloTabla.setValueAt((res.isAdministracion())?new Integer(ADMIN):new Integer(SOCIO), i, res.getWeekDay()+1);
					modeloTabla.setValueAt((res.isAdministracion())?new Integer(ADMIN):new Integer(SOCIO), res.getStartHour(), res.getWeekDay()+1);
			}	
		}
	}
	
	/**
	 * este metodo rellena la tabla.
	 * es una gochada pero tira bien
	 */
	private void a�adirFilas(){
		modeloTabla.getDataVector().clear();
		String[] nuevaFila = new String[8];//8 columnas
		for(int i=0;i< 24;i++){//bucle que recorre las horas, de inicio pone todas las casillas en blanco
			modeloTabla.addRow(nuevaFila);
		}
	}
	
//	private void colorear(){
//		for(int i = 0;i < modeloTabla.getRowCount();i++)
//			for(int j = 1;j <modeloTabla.getColumnCount() ;j++)
//				if (Integer.parseInt((String) modeloTabla.getValueAt(i, j))==ADMIN){
//					getTableMain().setCell.setBackground(Color.red);
//				}
//				else if(Integer.parseInt((String) modeloTabla.getValueAt(i, j))==SOCIO){
//
//				}
//			      {
//					getTableMain().set
//		        	this.setForeground(Color.red);
//		        	this.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
//			      }	
//	}
//	
		
	public void close(){
		vR.dispose();
		fillCalendar();
	}


}




